package contract;


public enum UserOrder {


	Right,

	Left,

	Up,
	
	Down,
	
	Noop
}
