package contract;

import java.util.Observable;

public interface IModel {

	char[][] getMap();

	Observable getObservable();
}
