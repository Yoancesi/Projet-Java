package contract;

public interface ILauncher {

	public void launcher();
	
	/*
	@return tab [][]
	*/
	
	public char[][] getTable();
}
