package main;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class testmain {

	public static void main(String[] args) {
		
		class kaka extends JFrame {
			
			ImageIcon x = new ImageIcon("C:\\Users\\yopyo\\Pictures");
			Image image = x.getImage();
			
			
		}

	}
}
