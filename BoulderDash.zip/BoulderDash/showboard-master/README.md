# showboard Package [![Codacy Badge](https://api.codacy.com/project/badge/Grade/b88058a169264f78a48d4ee97189edc6)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Jean-Aymeric/showboard&amp;utm_campaign=Badge_Grade)
![Exia.Cesi](https://exia.cesi.fr/wp-content/themes/eice/assets/images/logo-header.png)

*Version 2.1*

*Author Anne-Emilie DIET*

## Class diagram
![Class diagram](vpp/fr.exia.png)
