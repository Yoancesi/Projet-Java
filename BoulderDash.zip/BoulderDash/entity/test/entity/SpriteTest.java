package entity;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class SpriteTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		Sprite testSprite = new Sprite(1, 2, "character.png", false);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSprite() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsPermeability() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsVisible() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetVisible() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetX() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetX() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetY() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetY() {
		fail("Not yet implemented");
	}

}
