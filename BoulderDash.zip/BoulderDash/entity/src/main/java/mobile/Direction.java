package mobile;

public enum Direction {
	RIGHT,
	LEFT,
	UP,
	DOWN,
	NOTHING;
}
